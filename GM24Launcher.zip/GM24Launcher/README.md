# GM24 Launcher (General Mobile 24 Pro · Android 14)

Pixel Launcher tarzı, sıfırdan yazılmış gerçek bir Android launcher (Kotlin, View tabanlı).

## GitHub'da derleme
1. Bu klasörün içeriğini yeni bir GitHub deposuna yükle (`main` dalı).
2. **Actions → Build APK** otomatik çalışır (veya *Run workflow*).
3. Bittiğinde **Artifacts → GM24-Launcher-debug** içinden APK'yı indir.
4. Telefonda APK'yı kur, Ana tuşa bas → "GM24 Launcher" → **Her zaman**.
5. İlk açılışta: uzun bas → *Ana ekran ayarları* → bildirim erişimi, takvim ve konum izinlerini ver.

Yerelde: `gradle assembleDebug` (JDK 17, Android SDK 34).
