package com.gm24.launcher

import android.Manifest
import android.app.WallpaperManager
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class SettingsActivity : AppCompatActivity() {
    private lateinit var pal: Palette
    private lateinit var body: LinearLayout
    private lateinit var scroll: ScrollView
    private var tab = 0
    private val mode by lazy { intent.getStringExtra("mode") ?: "style" }
    private val tabNames = listOf("Duvar kağıdı", "Renkler", "Simgeler", "Düzen")

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> uri?.let { applyPhoto(it) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tab = b?.getInt("tab") ?: 0
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Apps.list.isEmpty()) Apps.load(this)
        build()
        CrashLog.check(this)
    }
    override fun onSaveInstanceState(o: Bundle) { super.onSaveInstanceState(o); o.putInt("tab", tab) }

    // ------------------------------------------------------------ helpers
    private fun tv(t: String, sz: Float, col: Int = pal.onSurface, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(col); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun round(c: Int, r: Float) = GradientDrawable().apply { setColor(c); cornerRadius = dpf(r) }
    private fun head(t: String) { body.addView(tv(t, 14f, pal.primary, true).apply { setPadding(dp(4), dp(22), 0, dp(6)) }) }
    private fun change(k: String, v: Any) {
        Prefs.put(k, v)
        if (k == "hue") Prefs.put("seed", Color.HSVToColor(floatArrayOf((v as Int).toFloat(), 0.7f, 0.9f)))
        Icons.clear(); rebuild()
    }
    private fun rebuild() { val y = if (::scroll.isInitialized) scroll.scrollY else 0; build(); scroll.post { scroll.scrollY = y } }

    private fun sw(title: String, key: String, def: Boolean, sub: String? = null, after: ((Boolean) -> Unit)? = null) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(10), dp(4), dp(10)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(tv(title, 16f)); if (sub != null) col.addView(tv(sub, 12f, pal.onSurface and 0x00FFFFFF or 0xAA000000.toInt()))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        val st = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        row.addView(Switch(this).apply {
            isChecked = Prefs.b(key, def)
            trackTintList = ColorStateList(st, intArrayOf(pal.primary, pal.surfaceVar))
            thumbTintList = ColorStateList(st, intArrayOf(pal.onPrimary, pal.onSurface))
            setOnCheckedChangeListener { _, c -> after?.invoke(c); change(key, c) }
        })
        body.addView(row)
    }

    private fun chip(t: String, sel: Boolean, a: () -> Unit) = tv(t, 14f, if (sel) pal.onPrimary else pal.onSurface).apply {
        background = round(if (sel) pal.primary else pal.surfaceVar, 18f); setPadding(dp(16), dp(9), dp(16), dp(9)); setOnClickListener { a() }
    }

    private fun chips(title: String, key: String, opts: List<Pair<String, Any>>, def: Any, after: (() -> Unit)? = null) {
        body.addView(tv(title, 16f).apply { setPadding(dp(4), dp(10), 0, dp(6)) })
        val row = LinearLayout(this)
        val cur = (Prefs.any(key) ?: def).toString()
        opts.forEach { (l, v) -> row.addView(chip(l, cur == v.toString()) { Prefs.put(key, v); after?.invoke(); change(key, v) }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) }) }
        body.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
    }

    private fun slider(title: String, key: String, min: Int, max: Int, def: Int, suffix: String = "") {
        val cur = Prefs.i(key, def)
        val label = tv("$title: $cur$suffix", 16f).apply { setPadding(dp(4), dp(10), 0, 0) }
        body.addView(label)
        body.addView(SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            progressTintList = ColorStateList.valueOf(pal.primary); thumbTintList = ColorStateList.valueOf(pal.primary)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "$title: ${p + min}$suffix" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { change(key, progress + min) }
            })
        })
    }

    private fun btn(title: String, sub: String? = null, act: () -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = round(pal.surfaceVar, 20f); setOnClickListener { act() } }
        col.addView(tv(title, 16f)); if (sub != null) col.addView(tv(sub, 12f, pal.onSurface and 0x00FFFFFF or 0xAA000000.toInt()))
        body.addView(col, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
    }

    // ------------------------------------------------------------ build
    private fun build() {
        pal = Pal.get(this)
        val rootV = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(pal.surface) }
        ViewCompat.setOnApplyWindowInsetsListener(rootV) { v, w ->
            val s = w.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(0, s.top, 0, s.bottom); WindowInsetsCompat.CONSUMED
        }
        WindowInsetsControllerCompat(window, rootV).isAppearanceLightStatusBars = !Pal.night(this)
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(16), dp(4)) }
        top.addView(tv("←", 26f).apply { setPadding(dp(12), dp(4), dp(16), dp(4)); setOnClickListener { finish() } })
        top.addView(tv(if (mode == "style") "Duvar kağıdı ve stil" else "Ana ekran ayarları", 22f))
        rootV.addView(top)
        if (mode == "style") {
            rootV.addView(preview(), LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(16), dp(4), dp(16), dp(8)) })
            val tabs = LinearLayout(this).apply { setPadding(dp(12), 0, dp(12), dp(4)) }
            tabNames.forEachIndexed { i, n -> tabs.addView(chip(n, i == tab) { tab = i; rebuild() }, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) }) }
            rootV.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(tabs) })
        }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), 0, dp(16), dp(32)) }
        scroll = ScrollView(this).apply { addView(body) }
        rootV.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(rootV)
        if (mode == "style") when (tab) { 0 -> wallTab(); 1 -> colorTab(); 2 -> iconTab(); else -> layoutTab() } else homeTab()
    }

    private fun preview(): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = round(pal.container, 28f); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val sz = dp(48)
        Apps.list.take(5).forEach { e -> row.addView(ImageView(this).apply { setImageDrawable(Icons.get(this@SettingsActivity, e, sz, pal)) }, LinearLayout.LayoutParams(0, sz, 1f)) }
        card.addView(row)
        card.addView(tv("🔍  Ara…", 15f, pal.onSurface).apply { background = round(pal.surfaceVar, 22f); setPadding(dp(18), dp(10), dp(18), dp(10)) },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        return card
    }

    // ------------------------------------------------------------ Wallpaper tab
    private val grads = listOf(
        intArrayOf(0xFF1E3A8A.toInt(), 0xFF7C3AED.toInt(), 0xFFF472B6.toInt()), intArrayOf(0xFF064E3B.toInt(), 0xFF10B981.toInt(), 0xFFFDE68A.toInt()),
        intArrayOf(0xFF111827.toInt(), 0xFF374151.toInt(), 0xFFF59E0B.toInt()), intArrayOf(0xFF7F1D1D.toInt(), 0xFFEF4444.toInt(), 0xFFFDBA74.toInt()),
        intArrayOf(0xFF0F172A.toInt(), 0xFF0EA5E9.toInt(), 0xFFA7F3D0.toInt()), intArrayOf(0xFF312E81.toInt(), 0xFF6366F1.toInt(), 0xFFFBCFE8.toInt()),
        intArrayOf(0xFF3F0D12.toInt(), 0xFFA71D31.toInt(), 0xFFF0F757.toInt()), intArrayOf(0xFF042F2E.toInt(), 0xFF14B8A6.toInt(), 0xFFFEF3C7.toInt()),
        intArrayOf(0xFF1F2937.toInt(), 0xFF9CA3AF.toInt(), 0xFFF9FAFB.toInt()), intArrayOf(0xFF581C87.toInt(), 0xFFC026D3.toInt(), 0xFFFDA4AF.toInt()))

    private fun wallTab() {
        chips("Uygulanacak yer", "wpTarget", listOf("Ana ekran" to "1", "Kilit ekranı" to "2", "İkisi" to "3"), "3")
        btn("Fotoğraf seç", "Galeriden duvar kağıdı belirle") { picker.launch("image/*") }
        btn("Sistem duvar kağıdı seçici", "Cihazdaki Google Wallpapers / AI / Emoji Workshop vb.") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Duvar kağıdı"))
        }
        head("Hazır duvar kağıtları")
        val row = LinearLayout(this)
        grads.forEach { g ->
            row.addView(View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, g).apply { cornerRadius = dpf(16f) }
                setOnClickListener { setWall(gradientBitmap(g)) }
            }, LinearLayout.LayoutParams(dp(84), dp(130)).apply { rightMargin = dp(10) })
        }
        body.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        head("Görünüm")
        slider("Karartma", "dim", 0, 70, 0, "%")
        sw("Sayfa kaydırırken duvar kağıdı kaysın", "wpScroll", true)
    }

    private fun screenSize() = resources.displayMetrics.let { Pair(it.widthPixels, it.heightPixels) }

    private fun gradientBitmap(g: IntArray): Bitmap {
        val (w, h) = screenSize()
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), g, null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = RadialGradient(w * 0.3f, h * 0.25f, w * 0.9f, intArrayOf(0x44FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        return b
    }

    private fun applyPhoto(uri: Uri) {
        try {
            val src = android.graphics.ImageDecoder.createSource(contentResolver, uri)
            val bmp = android.graphics.ImageDecoder.decodeBitmap(src) { d, info, _ ->
                d.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                d.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / 2800))
            }
            val (tw, th) = screenSize(); val tr = tw.toFloat() / th; val br = bmp.width.toFloat() / bmp.height
            val cw = if (br > tr) (bmp.height * tr).toInt() else bmp.width
            val ch = if (br > tr) bmp.height else (bmp.width / tr).toInt()
            setWall(Bitmap.createBitmap(bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch))
        } catch (e: Exception) { Toast.makeText(this, "Görsel açılamadı", Toast.LENGTH_SHORT).show() }
    }

    private fun setWall(bmp: Bitmap) {
        val f = when (Prefs.s("wpTarget", "3")) { "1" -> WallpaperManager.FLAG_SYSTEM; "2" -> WallpaperManager.FLAG_LOCK; else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK }
        Thread {
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, f)
                runOnUiThread { Prefs.put("wpRev", System.currentTimeMillis()); Toast.makeText(this, "Duvar kağıdı uygulandı", Toast.LENGTH_SHORT).show(); rebuild() }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Uygulanamadı", Toast.LENGTH_SHORT).show() } }
        }.start()
    }

    // ------------------------------------------------------------ Colors tab
    private val seeds = listOf(0xFF3B6EF5, 0xFF0F9D58, 0xFFD946EF, 0xFFF97316, 0xFFEF4444, 0xFF0EA5E9, 0xFF8B5CF6, 0xFF14B8A6, 0xFFEAB308, 0xFF64748B)

    private fun colorTab() {
        sw("Dinamik renk (Material You)", "dynamic", true, "Renkler duvar kağıdından türetilir")
        if (!Prefs.b("dynamic", true)) {
            head("Vurgu rengi")
            val row = LinearLayout(this); val cur = Prefs.i("seed", 0xFF3B6EF5.toInt())
            seeds.forEach { s ->
                row.addView(View(this).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(s.toInt()); if (cur == s.toInt()) setStroke(dp(3), pal.onSurface) }
                    setOnClickListener { change("seed", s.toInt()) }
                }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
            }
            body.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
            val hv = FloatArray(3); Color.colorToHSV(cur, hv)
            slider("Özel ton", "hue", 0, 360, hv[0].toInt())
        }
        chips("Renk yoğunluğu", "density", listOf("Neutral" to 0, "Soft" to 1, "Bright" to 2, "Bold" to 3), 2)
        chips("Tema", "theme", listOf("Sistem" to 0, "Açık" to 1, "Koyu" to 2), 0) { AppCompatDelegate.setDefaultNightMode(Prefs.nightMode()) }
    }

    // ------------------------------------------------------------ Icons tab
    private fun iconTab() {
        head("Simge şekli")
        val row = LinearLayout(this); val cur = Prefs.s("shape", "circle")
        listOf("circle" to "Daire", "square" to "Kare", "cookie4" to "Kurabiye 4", "cookie7" to "Kurabiye 7", "arch" to "Kemer").forEach { (k, n) ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(8))
                background = round(if (cur == k) pal.container else pal.surfaceVar, 18f); setOnClickListener { change("shape", k) }
            }
            col.addView(ImageView(this).apply { setImageBitmap(Icons.shapeBitmap(k, dp(52), pal.primary)) }, LinearLayout.LayoutParams(dp(52), dp(52)))
            col.addView(tv(n, 11f))
            row.addView(col, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        body.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        sw("Temalı simgeler (Beta)", "themed", false, "Tüm simgeleri renk paletine uydurur")
        sw("Uygulama adlarını göster", "labels", true)
        sw("Bildirim noktaları", "dots", true)
        slider("Simge boyutu", "iconScale", 70, 130, 100, "%")
    }

    // ------------------------------------------------------------ Layout tab
    private fun layoutTab() {
        val re = { Prefs.relayout() }
        chips("Sütun", "cols", listOf("4" to 4, "5" to 5, "6" to 6), 4) { re() }
        chips("Satır", "rows", listOf("4" to 4, "5" to 5, "6" to 6, "7" to 7), 5) { re() }
        chips("Dock simgeleri", "dockN", listOf("4" to 4, "5" to 5), 4) { re() }
        sw("At a Glance", "glance", true)
        sw("Arama çubuğu", "search", true)
        sw("Dock üstünde önerilen uygulamalar", "sugHome", true)
    }

    // ------------------------------------------------------------ Home settings
    private fun perm(p: String) { ActivityCompat.requestPermissions(this, arrayOf(p), 1) }

    private fun homeTab() {
        head("At a Glance")
        sw("At a Glance", "glance", true)
        sw("Hava durumu", "gl_weather", true, "Konum izni gerekir (yaklaşık konum)") { if (it) perm(Manifest.permission.ACCESS_COARSE_LOCATION) }
        sw("Yaklaşan etkinlikler", "gl_calendar", true, "Takvim izni gerekir") { if (it) perm(Manifest.permission.READ_CALENDAR) }
        sw("Alarm", "gl_alarm", true)
        sw("Pil / şarj", "gl_battery", true)
        head("Öneriler")
        sw("Ana ekranda öneriler", "sugHome", true)
        sw("Uygulama listesinde öneriler", "sugDrawer", true)
        head("Genel")
        sw("Bildirim noktaları", "dots", true)
        btn("Bildirim erişimi ver", "Noktaların çalışması için gerekli") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        sw("Yeni uygulama simgelerini ana ekrana ekle", "autoAdd", true)
        sw("Ana ekran döndürmeye izin ver", "rotate", false)
        sw("Aşağı kaydırınca bildirim paneli", "swipeDown", true)
        head("Arama çubuğu")
        chips("Kısayollar", "sIcons", listOf("Mikrofon+Lens+AI" to "all", "Sadece mikrofon" to "mic", "Yok" to "none"), "all")
        head("Gizli uygulamalar")
        btn("Gizli uygulamaları yönet", "${Prefs.hidden().size} gizli uygulama") { hiddenDialog() }
        head("Diğer")
        btn("Varsayılan ana ekran uygulaması", "Sistem ayarlarını açar") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        btn("Ana ekranı sıfırla", "Simgeleri varsayılan düzene döndürür") {
            AlertDialog.Builder(this).setTitle("Ana ekran sıfırlansın mı?").setPositiveButton("Sıfırla") { _, _ ->
                Prefs.items.clear(); Prefs.save(); Prefs.put("init", false); Toast.makeText(this, "Sıfırlandı", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("İptal", null).show()
        }
    }

    private fun hiddenDialog() {
        val hid = Prefs.hidden().toList()
        if (hid.isEmpty()) { Toast.makeText(this, "Gizli uygulama yok", Toast.LENGTH_SHORT).show(); return }
        val checked = BooleanArray(hid.size) { true }
        AlertDialog.Builder(this).setTitle("İşaretli kalanlar gizli kalır")
            .setMultiChoiceItems(hid.map { Apps.find(it)?.label ?: it }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Tamam") { _, _ -> Prefs.setHidden(hid.filterIndexed { i, _ -> checked[i] }.toSet()); rebuild() }
            .setNegativeButton("İptal", null).show()
    }
}
