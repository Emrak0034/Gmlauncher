package com.gm24.launcher

import android.content.Context
import android.view.View
import android.view.ViewGroup

class CellLayout(c: Context) : ViewGroup(c) {
    var cols = 5
    var rows = 5

    class LP(var cx: Int, var cy: Int, var sx: Int = 1, var sy: Int = 1) : ViewGroup.LayoutParams(0, 0)

    private fun cw() = (width - paddingLeft - paddingRight) / maxOf(1, cols)
    private fun ch() = (height - paddingTop - paddingBottom) / maxOf(1, rows)

    override fun onMeasure(w: Int, h: Int) {
        val W = MeasureSpec.getSize(w); val H = MeasureSpec.getSize(h)
        setMeasuredDimension(W, H)
        val cw = (W - paddingLeft - paddingRight) / maxOf(1, cols); val ch = (H - paddingTop - paddingBottom) / maxOf(1, rows)
        for (i in 0 until childCount) {
            val v = getChildAt(i); val lp = v.layoutParams as LP
            v.measure(MeasureSpec.makeMeasureSpec(cw * lp.sx, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch * lp.sy, MeasureSpec.EXACTLY))
        }
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = cw(); val ch = ch()
        for (i in 0 until childCount) {
            val v = getChildAt(i); val lp = v.layoutParams as LP
            val x = paddingLeft + lp.cx * cw; val y = paddingTop + lp.cy * ch
            v.layout(x, y, x + cw * lp.sx, y + ch * lp.sy)
        }
    }
    override fun checkLayoutParams(p: ViewGroup.LayoutParams?) = p is LP

    fun cellAt(px: Float, py: Float): Pair<Int, Int> {
        val x = ((px - paddingLeft) / maxOf(1, cw())).toInt().coerceIn(0, cols - 1)
        val y = ((py - paddingTop) / maxOf(1, ch())).toInt().coerceIn(0, rows - 1)
        return Pair(x, y)
    }
}
