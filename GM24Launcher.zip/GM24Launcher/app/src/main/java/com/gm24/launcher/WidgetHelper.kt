package com.gm24.launcher

import android.app.Activity
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager

class WidgetHelper(private val act: Activity) {
    val mgr: AppWidgetManager = AppWidgetManager.getInstance(act)
    val host = AppWidgetHost(act, 1024)
    fun start() { try { host.startListening() } catch (e: Exception) {} }
    fun stop() { try { host.stopListening() } catch (e: Exception) {} }
    fun view(id: Int): AppWidgetHostView? {
        val info = mgr.getAppWidgetInfo(id) ?: return null
        return host.createView(act, id, info)
    }
}
