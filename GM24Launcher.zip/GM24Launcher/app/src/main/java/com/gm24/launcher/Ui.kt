package com.gm24.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

data class Entry(val label: String, val icon: Drawable? = null, val action: () -> Unit)

fun showPopup(root: View, x: Int, y: Int, entries: List<Entry>, pal: Palette) {
    val ctx = root.context
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        background = GradientDrawable().apply { setColor(pal.surfaceVar); cornerRadius = ctx.dpf(24f) }
    }
    val pw = PopupWindow(box, WRAP, WRAP, true)
    pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    pw.elevation = ctx.dpf(10f)
    for (e in entries) {
        val ic = e.icon
        box.addView(TextView(ctx).apply {
            text = e.label; textSize = 15f; setTextColor(pal.onSurface)
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(22), ctx.dp(12)); gravity = Gravity.CENTER_VERTICAL
            if (ic != null) { ic.setBounds(0, 0, ctx.dp(24), ctx.dp(24)); setCompoundDrawables(ic, null, null, null); compoundDrawablePadding = ctx.dp(14) }
            setOnClickListener { pw.dismiss(); e.action() }
        })
    }
    val u = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
    box.measure(u, u)
    val w = box.measuredWidth; val h = box.measuredHeight
    val dm = ctx.resources.displayMetrics
    val px = (x - w / 2).coerceIn(ctx.dp(8), maxOf(ctx.dp(8), dm.widthPixels - w - ctx.dp(8)))
    var py = y - h - ctx.dp(8)
    if (py < ctx.dp(48)) py = y + ctx.dp(8)
    py = py.coerceIn(ctx.dp(24), maxOf(ctx.dp(24), dm.heightPixels - h - ctx.dp(24)))
    pw.showAtLocation(root, Gravity.NO_GRAVITY, px, py)
}

class PageDots(c: Context) : View(c) {
    private var n = 1; private var p = 0; private var col = Color.WHITE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    fun set(page: Int, count: Int, color: Int = col) {
        p = page; n = count; col = color; visibility = if (count > 1) VISIBLE else INVISIBLE; invalidate()
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), context.dp(14)) }
    override fun onDraw(cv: Canvas) {
        val gap = context.dp(14); var x = width / 2f - gap * (n - 1) / 2f
        for (i in 0 until n) {
            paint.color = col; paint.alpha = if (i == p) 255 else 110
            cv.drawCircle(x, height / 2f, context.dpf(if (i == p) 3.5f else 3f), paint); x += gap
        }
    }
}

/** Widget gibi çocuk görünümler dokunuşu tüketse bile uzun basmayı yakalar. */
class LongPressFrame(c: Context) : FrameLayout(c) {
    var onLong: (() -> Unit)? = null
    private val h = Handler(Looper.getMainLooper())
    private var sx = 0f; private var sy = 0f; private var fired = false
    private val run = Runnable { fired = true; onLong?.invoke() }
    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; fired = false; h.postDelayed(run, ViewConfiguration.getLongPressTimeout().toLong()) }
            MotionEvent.ACTION_MOVE -> if (Math.hypot((e.x - sx).toDouble(), (e.y - sy).toDouble()) > ViewConfiguration.get(context).scaledTouchSlop) h.removeCallbacks(run)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> h.removeCallbacks(run)
        }
        return fired
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) h.removeCallbacks(run)
        return true
    }
}
