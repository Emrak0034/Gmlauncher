package com.gm24.launcher

import android.content.Context
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import com.google.android.material.color.MaterialColors
import com.google.android.material.R as MR

class Palette(
    val primary: Int, val onPrimary: Int, val container: Int, val onContainer: Int,
    val surface: Int, val onSurface: Int, val surfaceVar: Int
)

object Pal {
    fun night(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    private fun hsv(h: Float, s: Float, v: Float) = Color.HSVToColor(floatArrayOf(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))
    private fun sat(c: Int, f: Float): Int {
        val a = FloatArray(3); Color.colorToHSV(c, a); a[1] = (a[1] * f).coerceIn(0f, 1f); return Color.HSVToColor(Color.alpha(c), a)
    }

    fun get(c: Context): Palette {
        val f = floatArrayOf(0.35f, 0.7f, 1f, 1.3f)[Prefs.i("density", 2).coerceIn(0, 3)]
        if (Prefs.b("dynamic", true) && Build.VERSION.SDK_INT >= 31) {
            fun col(a: Int, d: Int) = MaterialColors.getColor(c, a, d)
            return Palette(
                col(MR.attr.colorPrimary, Color.BLUE), col(MR.attr.colorOnPrimary, Color.WHITE),
                sat(col(MR.attr.colorSecondaryContainer, Color.LTGRAY), f), col(MR.attr.colorOnSecondaryContainer, Color.BLACK),
                col(MR.attr.colorSurface, Color.BLACK), col(MR.attr.colorOnSurface, Color.WHITE),
                sat(col(MR.attr.colorSurfaceContainerHigh, Color.DKGRAY), f)
            )
        }
        val hv = FloatArray(3); Color.colorToHSV(Prefs.i("seed", 0xFF3B6EF5.toInt()), hv); val h = hv[0]
        return if (night(c)) Palette(
            hsv(h, 0.30f + 0.25f * f, 0.95f), 0xFF1A1A1A.toInt(), hsv(h, 0.45f * f, 0.32f), hsv(h, 0.15f, 0.95f),
            hsv(h, 0.10f * f, 0.11f), 0xFFE6E1E5.toInt(), hsv(h, 0.22f * f, 0.22f)
        ) else Palette(
            hsv(h, 0.55f + 0.2f * f, 0.60f), Color.WHITE, hsv(h, 0.12f + 0.12f * f, 0.97f), hsv(h, 0.8f, 0.25f),
            hsv(h, 0.03f * f, 0.99f), 0xFF1C1B1F.toInt(), hsv(h, 0.10f * f, 0.93f)
        )
    }
}

object Icons {
    private val cache = HashMap<String, BitmapDrawable>()
    fun clear() = cache.clear()

    fun shapePath(shape: String, s: Float): Path {
        val p = Path(); val r = s / 2f
        when (shape) {
            "circle" -> p.addCircle(r, r, r, Path.Direction.CW)
            "square" -> p.addRoundRect(0f, 0f, s, s, s * 0.22f, s * 0.22f, Path.Direction.CW)
            "arch" -> p.addRoundRect(RectF(0f, 0f, s, s), floatArrayOf(r, r, r, r, s * 0.14f, s * 0.14f, s * 0.14f, s * 0.14f), Path.Direction.CW)
            else -> {
                val k = if (shape == "cookie4") 4 else 7; val a = if (k == 4) 0.09f else 0.06f
                val n = 240
                for (i in 0..n) {
                    val t = i.toFloat() / n * 2f * Math.PI.toFloat()
                    val rr = r * (1f - a + a * Math.cos((k * t).toDouble()).toFloat())
                    val x = r + rr * Math.cos(t.toDouble()).toFloat(); val y = r + rr * Math.sin(t.toDouble()).toFloat()
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }

    fun shapeBitmap(shape: String, size: Int, color: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(b).drawPath(shapePath(shape, size.toFloat()), Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
        return b
    }

    fun get(ctx: Context, e: AppEntry, size: Int, pal: Palette): BitmapDrawable {
        val shape = Prefs.s("shape", "circle"); val themed = Prefs.b("themed", false)
        return cache.getOrPut("${e.key}|$size|$shape|$themed|${pal.container}") { make(ctx, e.info.getIcon(0), size, pal, shape, themed) }
    }

    private fun make(ctx: Context, src: Drawable, size: Int, pal: Palette, shape: String, themed: Boolean): BitmapDrawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.clipPath(shapePath(shape, size.toFloat()))
        val off = (size * 0.25f).toInt()
        val big = Rect(-off, -off, size + off, size + off)
        val tint = PorterDuffColorFilter(pal.onContainer, PorterDuff.Mode.SRC_IN)
        if (src is AdaptiveIconDrawable) {
            if (themed) {
                c.drawColor(pal.container)
                val mono = if (Build.VERSION.SDK_INT >= 33) src.monochrome else null
                val fg = mono ?: src.foreground
                fg?.let { it.setBounds(big.left, big.top, big.right, big.bottom); it.colorFilter = tint; it.draw(c); it.colorFilter = null }
            } else {
                src.background?.let { it.setBounds(big.left, big.top, big.right, big.bottom); it.draw(c) }
                src.foreground?.let { it.setBounds(big.left, big.top, big.right, big.bottom); it.draw(c) }
            }
        } else {
            c.drawColor(if (themed) pal.container else 0xFFF2F2F2.toInt())
            val i = (size * 0.19f).toInt()
            src.setBounds(i, i, size - i, size - i)
            if (themed) src.colorFilter = tint
            src.draw(c)
        }
        return BitmapDrawable(ctx.resources, bmp)
    }

    fun folder(ctx: Context, es: List<AppEntry>, size: Int, pal: Palette): BitmapDrawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888); val c = Canvas(bmp)
        c.drawPath(shapePath(Prefs.s("shape", "circle"), size.toFloat()), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.container })
        val mini = (size * 0.36f).toInt(); val gap = (size - 2 * mini) / 3
        es.take(4).forEachIndexed { i, e ->
            val d = get(ctx, e, mini, pal)
            c.drawBitmap(d.bitmap, (gap + (i % 2) * (mini + gap)).toFloat(), (gap + (i / 2) * (mini + gap)).toFloat(), null)
        }
        return BitmapDrawable(ctx.resources, bmp)
    }
}
