package com.gm24.launcher

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.color.DynamicColors

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        DynamicColors.applyToActivitiesIfAvailable(this)
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
    }
}
