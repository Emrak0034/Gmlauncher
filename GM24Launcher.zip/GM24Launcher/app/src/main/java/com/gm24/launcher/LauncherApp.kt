package com.gm24.launcher

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.color.DynamicColors

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        Prefs.init(this)
        DynamicColors.applyToActivitiesIfAvailable(this)
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
    }
}

/** Çökme olursa iz dosyaya yazılır; "GM24 Launcher Ayarları" açılınca gösterilir. */
object CrashLog {
    fun install(app: Application) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { java.io.File(app.filesDir, "crash.txt").writeText(android.util.Log.getStackTraceString(e).take(3500)) } catch (x: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    fun check(a: android.app.Activity) {
        val f = java.io.File(a.filesDir, "crash.txt")
        if (!f.exists()) return
        val txt = try { f.readText() } catch (e: Throwable) { return }
        f.delete()
        androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Son çökme kaydı").setMessage(txt)
            .setPositiveButton("Kopyala") { _, _ ->
                a.getSystemService(android.content.ClipboardManager::class.java).setPrimaryClip(android.content.ClipData.newPlainText("crash", txt))
            }
            .setNegativeButton("Kapat", null).show()
    }
}
