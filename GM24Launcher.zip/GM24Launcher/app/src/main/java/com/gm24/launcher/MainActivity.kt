package com.gm24.launcher

import android.app.WallpaperManager
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object { const val REQ_BIND = 11; const val REQ_CFG = 12 }

    private lateinit var root: CoordinatorLayout
    private lateinit var homeCol: LinearLayout
    private lateinit var scrim: View
    private lateinit var glance: GlanceView
    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDots
    private lateinit var sugRow: LinearLayout
    private lateinit var dock: CellLayout
    private lateinit var search: LinearLayout
    private lateinit var sG: TextView
    private lateinit var sHint: TextView
    private lateinit var sIcons: LinearLayout
    private lateinit var dragBar: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var sheet: BottomSheetBehavior<LinearLayout>
    private lateinit var dq: EditText
    private lateinit var dlist: RecyclerView
    private lateinit var dAdapter: DrawerAdapter
    private lateinit var wh: WidgetHelper
    private lateinit var la: LauncherApps
    private lateinit var wm: WallpaperManager
    private lateinit var pal: Palette

    private var textColor = Color.WHITE
    private var insetTop = 0
    private var dragItem: Item? = null
    private var dragStart = PointF()
    private var extraPage = false
    private var lastX = 0f
    private var lastY = 0f
    private var gestureOk = false
    private var pendingWidget = -1
    private var hoverDir = 0
    private val handler = Handler(Looper.getMainLooper())
    private var lastOff = -1f
    private val notifRun = Runnable { refreshAll() }
    private lateinit var dqRow: LinearLayout

    // ---------------------------------------------------------------- lifecycle
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        la = getSystemService(LauncherApps::class.java)
        wm = WallpaperManager.getInstance(this)
        wh = WidgetHelper(this)
        Apps.load(this)
        if (!Prefs.b("init", false)) firstRun()
        pal = Pal.get(this)
        buildUi()
        applyAll()
        Icons.prewarm(this, pal, listOf(iconSize(Prefs.cols), iconSize(Prefs.dockN)))
        la.registerCallback(cb)
        NotifService.onChange = { if (Prefs.b("dots", true)) { handler.removeCallbacks(notifRun); handler.postDelayed(notifRun, 600) } }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goHome() }
        })
    }

    override fun onStart() { super.onStart(); wh.start() }
    override fun onStop() { super.onStop(); wh.stop() }
    override fun onDestroy() { super.onDestroy(); try { la.unregisterCallback(cb) } catch (e: Exception) {}; NotifService.onChange = null }

    override fun onResume() {
        super.onResume()
        if (!Prefs.b("init", false)) { Apps.load(this); firstRun() }
        if (Prefs.dirty) { Prefs.dirty = false; Prefs.relayout(); applyAll() }
        glance.refresh(); updateSug()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); if (intent.action == Intent.ACTION_MAIN) goHome() }

    private fun goHome() {
        if (sheet.state != BottomSheetBehavior.STATE_HIDDEN) sheet.state = BottomSheetBehavior.STATE_HIDDEN
        else if (pager.currentItem != 0) pager.setCurrentItem(0, true)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------------------------------------------------------- first run
    private fun firstRun() {
        Prefs.put("init", true)
        Prefs.items.clear()
        fun pk(i: Intent): AppEntry? {
            val p = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName ?: return null
            if (p == "android") return null
            return Apps.list.firstOrNull { it.pkg == p }
        }
        fun cat(c: String) = Intent(Intent.ACTION_MAIN).addCategory(c)
        val dockE = listOf(
            Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), cat(Intent.CATEGORY_APP_GALLERY)
        ).mapNotNull { pk(it) }.distinctBy { it.pkg }
        dockE.take(Prefs.dockN).forEachIndexed { i, e -> Prefs.items.add(Item(Prefs.nextId(), "APP", -1, i, 0, pkg = e.pkg, cls = e.cls)) }
        val used = dockE.map { it.pkg }.toMutableSet()
        val homeE = mutableListOf<AppEntry>()
        listOf(cat(Intent.CATEGORY_APP_EMAIL), cat(Intent.CATEGORY_APP_CALENDAR), cat(Intent.CATEGORY_APP_MAPS),
            cat(Intent.CATEGORY_APP_MUSIC), cat(Intent.CATEGORY_APP_CALCULATOR), cat(Intent.CATEGORY_APP_CONTACTS))
            .mapNotNull { pk(it) }.forEach { if (used.add(it.pkg)) homeE.add(it) }
        listOf("com.android.vending", "com.google.android.youtube", "com.android.settings").forEach { p ->
            Apps.list.firstOrNull { it.pkg == p }?.let { if (used.add(it.pkg)) homeE.add(it) }
        }
        homeE.forEachIndexed { i, e -> Prefs.items.add(Item(Prefs.nextId(), "APP", 0, i % Prefs.cols, i / Prefs.cols, pkg = e.pkg, cls = e.cls)) }
        Prefs.save()
    }

    // ---------------------------------------------------------------- UI build
    private fun buildUi() {
        root = CoordinatorLayout(this)
        scrim = View(this); root.addView(scrim, CoordinatorLayout.LayoutParams(MATCH, MATCH))

        homeCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(homeCol, CoordinatorLayout.LayoutParams(MATCH, MATCH))

        glance = GlanceView(this).apply { onLong = { openSettings("home") } }
        homeCol.addView(glance, LinearLayout.LayoutParams(MATCH, WRAP))

        pager = ViewPager2(this).apply { adapter = PageAdapter(); offscreenPageLimit = 1 }
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageScrolled(pos: Int, off: Float, px: Int) {
                glance.alpha = if (pos == 0) 1f - off else 0f
                val n = pageCount()
                val o = (pos + off) / maxOf(1, n - 1)
                if (Math.abs(o - lastOff) > 0.004f && Prefs.b("wpScroll", true)) try {
                    wm.setWallpaperOffsetSteps(1f / maxOf(1, n - 1), 1f)
                    wm.setWallpaperOffsets(pager.windowToken, o, 0.5f)
                    lastOff = o
                } catch (e: Exception) {}
            }
            override fun onPageSelected(p: Int) { dots.set(p, pageCount(), textColor) }
        })
        homeCol.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))

        dots = PageDots(this); homeCol.addView(dots, LinearLayout.LayoutParams(MATCH, WRAP))
        sugRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), 0, dp(12), 0) }
        homeCol.addView(sugRow, LinearLayout.LayoutParams(MATCH, dp(86)))
        dock = CellLayout(this).apply { setPadding(dp(12), 0, dp(12), 0) }
        homeCol.addView(dock, LinearLayout.LayoutParams(MATCH, dp(86)))

        search = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(14), 0) }
        sG = TextView(this).apply { text = "G"; textSize = 22f; typeface = android.graphics.Typeface.DEFAULT_BOLD }
        sHint = TextView(this).apply { text = "Ara…"; textSize = 16f; setPadding(dp(14), 0, 0, 0) }
        sIcons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        search.addView(sG); search.addView(sHint, LinearLayout.LayoutParams(0, WRAP, 1f)); search.addView(sIcons)
        search.setOnClickListener { openDrawer(true) }
        search.setOnLongClickListener {
            showPopup(root, lastX.toInt(), lastY.toInt(), listOf(
                Entry("Kısayollar: Mikrofon + Lens + AI") { Prefs.put("sIcons", "all"); applyAll() },
                Entry("Kısayollar: Sadece mikrofon") { Prefs.put("sIcons", "mic"); applyAll() },
                Entry("Kısayolları gizle") { Prefs.put("sIcons", "none"); applyAll() },
                Entry("Ana ekran ayarları") { openSettings("home") }), pal); true
        }
        homeCol.addView(search, LinearLayout.LayoutParams(MATCH, dp(54)).apply { setMargins(dp(16), dp(6), dp(16), dp(14)) })

        // sürükleme çubuğu
        dragBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE }
        listOf("🗑 Kaldır", "ℹ️ Uygulama bilgisi", "⛔ Sil").forEach { t ->
            dragBar.addView(TextView(this).apply { text = t; gravity = Gravity.CENTER; textSize = 14f }, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
        root.addView(dragBar, CoordinatorLayout.LayoutParams(MATCH, dp(64)).apply { gravity = Gravity.TOP })

        // uygulama çekmecesi
        drawer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sheet = BottomSheetBehavior<LinearLayout>()
        root.addView(drawer, CoordinatorLayout.LayoutParams(MATCH, MATCH).apply { behavior = sheet })
        sheet.isHideable = true; sheet.skipCollapsed = true; sheet.peekHeight = 0; sheet.state = BottomSheetBehavior.STATE_HIDDEN
        sheet.addBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(v: View, s: Int) {
                homeCol.setLayerType(if (s == BottomSheetBehavior.STATE_DRAGGING || s == BottomSheetBehavior.STATE_SETTLING) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, null)
                if (s == BottomSheetBehavior.STATE_HIDDEN) { dq.setText(""); hideKb(); zoom(0f) }
            }
            override fun onSlide(v: View, o: Float) {
                val x = (o + 1f).coerceIn(0f, 1f)
                homeCol.alpha = 1f - x; homeCol.scaleX = 1f - 0.06f * x; homeCol.scaleY = 1f - 0.06f * x; zoom(x)
            }
        })
        dq = EditText(this).apply {
            hint = "Uygulamaları ara"; maxLines = 1; inputType = android.text.InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH; setPadding(dp(10), 0, dp(4), 0); textSize = 16f; background = null
        }
        dq.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { refreshDrawer(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        dq.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                if (dAdapter.apps.size == 1) { Apps.launch(this, dAdapter.apps[0], null); sheet.state = BottomSheetBehavior.STATE_HIDDEN }
                else webSearch(dq.text.toString()); true
            } else false
        }
        dqRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        dqRow.addView(TextView(this).apply { text = "🔍"; textSize = 18f; setPadding(dp(18), 0, 0, 0) })
        dqRow.addView(dq, LinearLayout.LayoutParams(0, MATCH, 1f))
        dqRow.addView(TextView(this).apply {
            text = "⋮"; textSize = 22f; setPadding(dp(14), 0, dp(18), 0)
            setOnClickListener { v -> val l = IntArray(2); v.getLocationOnScreen(l); showPopup(root, l[0], l[1], listOf(Entry("Ana ekran ayarları") { openSettings("home") }), pal) }
        })
        drawer.addView(dqRow, LinearLayout.LayoutParams(MATCH, dp(52)).apply { setMargins(dp(8), dp(12), dp(8), dp(8)) })
        dAdapter = DrawerAdapter()
        dlist = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, Prefs.cols).apply {
                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                    override fun getSpanSize(p: Int) = if (dAdapter.getItemViewType(p) == 1) 1 else spanCount
                }
            }
            adapter = dAdapter; clipToPadding = false; setHasFixedSize(true); setItemViewCacheSize(24)
        }
        drawer.addView(dlist, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.setOnDragListener { _, ev -> onDrag(ev) }
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, w ->
            val s = w.getInsets(WindowInsetsCompat.Type.systemBars()); val ime = w.getInsets(WindowInsetsCompat.Type.ime())
            insetTop = s.top
            homeCol.setPadding(0, s.top, 0, s.bottom)
            drawer.setPadding(dp(8), s.top, dp(8), maxOf(s.bottom, ime.bottom))
            (dragBar.layoutParams as CoordinatorLayout.LayoutParams).topMargin = s.top; dragBar.requestLayout()
            WindowInsetsCompat.CONSUMED
        }
        setContentView(root)
    }

    private val zoomM by lazy { try { WallpaperManager::class.java.getMethod("setWallpaperZoomOut", android.os.IBinder::class.java, Float::class.javaPrimitiveType) } catch (e: Throwable) { null } }
    private fun zoom(z: Float) { val m = zoomM ?: return; try { m.invoke(wm, root.windowToken, z) } catch (e: Throwable) {} }

    // ---------------------------------------------------------------- theming / apply
    private fun applyAll() {
        Icons.clear(); pal = Pal.get(this)
        var dark = false
        try {
            val c = wm.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
            dark = c != null && (c.colorHints and android.app.WallpaperColors.HINT_SUPPORTS_DARK_TEXT) != 0
        } catch (e: Exception) {}
        val dim = Prefs.i("dim", 0)
        if (dim > 35) dark = false
        textColor = if (dark) 0xFF1C1B1F.toInt() else Color.WHITE
        scrim.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        requestedOrientation = if (Prefs.b("rotate", false)) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        WindowInsetsControllerCompat(window, root).apply { isAppearanceLightStatusBars = dark; isAppearanceLightNavigationBars = dark }

        glance.visibility = if (Prefs.b("glance", true)) View.VISIBLE else View.GONE
        glance.style(textColor); glance.refresh()

        search.visibility = if (Prefs.b("search", true)) View.VISIBLE else View.GONE
        search.background = GradientDrawable().apply { setColor(pal.surfaceVar); cornerRadius = dpf(27f) }
        sG.setTextColor(pal.primary); sHint.setTextColor(pal.onSurface)
        sIcons.removeAllViews()
        val mode = Prefs.s("sIcons", "all")
        fun sIcon(t: String, a: () -> Unit) = sIcons.addView(TextView(this).apply { text = t; textSize = 20f; setPadding(dp(10), dp(6), dp(10), dp(6)); setTextColor(pal.onSurface); setOnClickListener { a() } })
        if (mode != "none") sIcon("🎙") { try { startActivity(Intent(RecognizerIntent.ACTION_WEB_SEARCH)) } catch (e: Exception) { toast("Sesli arama yok") } }
        if (mode == "all") {
            sIcon("◎") {
                val i = packageManager.getLaunchIntentForPackage("com.google.android.apps.lens") ?: packageManager.getLaunchIntentForPackage("com.google.android.googlequicksearchbox")
                if (i != null) startActivity(i) else toast("Google Lens yüklü değil")
            }
            sIcon("✦") { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?udm=50"))) } catch (e: Exception) {} }
        }

        dragBar.background = ColorDrawable(pal.surfaceVar)
        for (i in 0 until dragBar.childCount) (dragBar.getChildAt(i) as TextView).setTextColor(pal.onSurface)
        drawer.background = GradientDrawable().apply { setColor(Color.argb(245, Color.red(pal.surface), Color.green(pal.surface), Color.blue(pal.surface))) }
        dq.setTextColor(pal.onSurface); dq.setHintTextColor(pal.onSurface and 0x00FFFFFF or 0x99000000.toInt())
        dq.background = null
        dqRow.background = GradientDrawable().apply { setColor(pal.surfaceVar); cornerRadius = dpf(26f) }
        (dqRow.getChildAt(2) as TextView).setTextColor(pal.onSurface)

        (dlist.layoutManager as GridLayoutManager).spanCount = Prefs.cols
        refreshAll(); refreshDrawer(dq.text.toString())
    }

    private fun refreshAll() {
        pager.adapter?.notifyDataSetChanged(); populateDock(); updateSug()
        dots.set(pager.currentItem, pageCount(), textColor)
    }

    // ---------------------------------------------------------------- pages
    private fun pageCount(): Int {
        var m = 0
        for (i in Prefs.items) if (i.page > m) m = i.page
        return m + 1 + if (extraPage) 1 else 0
    }

    private inner class PageAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = pageCount()
        override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
            val c = CellLayout(p.context); c.layoutParams = RecyclerView.LayoutParams(MATCH, MATCH)
            return object : RecyclerView.ViewHolder(c) {}
        }
        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) { populate(h.itemView as CellLayout, pos) }
    }

    private fun currentPage(): CellLayout? =
        (pager.getChildAt(0) as RecyclerView).findViewHolderForAdapterPosition(pager.currentItem)?.itemView as? CellLayout

    private fun populate(cell: CellLayout, page: Int) {
        cell.removeAllViews(); cell.cols = Prefs.cols; cell.rows = Prefs.rows
        cell.setPadding(dp(8), dp(4), dp(8), dp(4))
        for (item in Prefs.items.filter { it.page == page }) viewFor(item, false)?.let { cell.addView(it, CellLayout.LP(item.x, item.y, item.sx, item.sy)) }
        cell.setOnLongClickListener { showPopup(root, lastX.toInt(), lastY.toInt(), workspaceMenu(), pal); true }
    }

    private fun populateDock() {
        dock.removeAllViews(); dock.cols = Prefs.dockN; dock.rows = 1
        for (item in Prefs.items.filter { it.page == -1 }) viewFor(item, true)?.let { dock.addView(it, CellLayout.LP(item.x, 0, 1, 1)) }
    }

    private fun workspaceMenu() = listOf(
        Entry("🎨  Duvar kağıdı ve stil") { openSettings("style") },
        Entry("🧩  Widget'lar") { widgetPicker(null) },
        Entry("📱  Uygulama listesi") { openDrawer(false) },
        Entry("⚙️  Ana ekran ayarları") { openSettings("home") })

    private fun openSettings(mode: String) = startActivity(Intent(this, SettingsActivity::class.java).putExtra("mode", mode))

    // ---------------------------------------------------------------- item views
    private fun iconSize(c: Int): Int {
        val maxPx = resources.displayMetrics.widthPixels / maxOf(1, c) * 0.78f
        return minOf(dp(56) * Prefs.i("iconScale", 100) / 100, maxPx.toInt())
    }

    private fun cellView(d: Drawable, label: String, showLabel: Boolean, count: Int, tc: Int, size: Int): LinearLayout {
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(2), dp(4), dp(2), dp(2)) }
        val fl = FrameLayout(this)
        fl.addView(ImageView(this).apply { setImageDrawable(d) }, FrameLayout.LayoutParams(size, size))
        if (count > 0 && Prefs.b("dots", true)) fl.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE); setStroke(dp(2), pal.primary) }
        }, FrameLayout.LayoutParams(dp(13), dp(13), Gravity.TOP or Gravity.END))
        ll.addView(fl, LinearLayout.LayoutParams(size, size))
        if (showLabel && Prefs.b("labels", true)) ll.addView(TextView(this).apply {
            text = label; setTextColor(tc); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            if (tc == Color.WHITE) setShadowLayer(4f, 0f, 1f, 0x66000000)
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
        return ll
    }

    private fun viewFor(item: Item, inDock: Boolean): View? {
        val cols = if (inDock) Prefs.dockN else Prefs.cols
        return when (item.type) {
            "APP" -> {
                val e = Apps.find(item.key()) ?: return null
                cellView(Icons.get(this, e, iconSize(cols), pal), e.label, !inDock, NotifService.counts[e.pkg] ?: 0, textColor, iconSize(cols)).also { v ->
                    v.tag = item
                    v.setOnClickListener { Apps.launch(this, e, v) }
                    v.setOnLongClickListener { startDragItem(v, item); true }
                }
            }
            "FOLDER" -> {
                val es = item.children.mapNotNull { Apps.find(it) }
                val sz = iconSize(cols)
                cellView(Icons.folder(this, es, sz, pal), item.title.ifEmpty { "Klasör" }, !inDock, 0, textColor, sz).also { v ->
                    v.tag = item
                    v.setOnClickListener { openFolder(item) }
                    v.setOnLongClickListener { startDragItem(v, item); true }
                }
            }
            else -> widgetView(item)
        }
    }

    private fun widgetView(item: Item): View? {
        val hv: AppWidgetHostView = wh.view(item.widgetId) ?: return null
        val w = LongPressFrame(this)
        w.tag = item; w.setPadding(dp(4), dp(4), dp(4), dp(4)); w.clipToOutline = true
        w.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dpf(24f)) }
        }
        w.onLong = { startDragItem(w, item) }
        w.addView(hv, FrameLayout.LayoutParams(MATCH, MATCH))
        hv.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            val d = resources.displayMetrics.density
            val wd = ((r - l) / d).toInt(); val ht = ((b - t) / d).toInt()
            (v as AppWidgetHostView).updateAppWidgetSize(null, wd, ht, wd, ht)
        }
        return w
    }

    // ---------------------------------------------------------------- drag & drop
    private fun startDragItem(v: View, item: Item) {
        dragItem = item
        v.startDragAndDrop(ClipData.newPlainText("i", "i"), View.DragShadowBuilder(v), null, View.DRAG_FLAG_OPAQUE)
        v.visibility = View.INVISIBLE
    }

    private val hoverRun = object : Runnable {
        override fun run() {
            if (hoverDir == 0) return
            val n = pager.currentItem + hoverDir
            if (n >= 0) {
                if (n >= pageCount()) { extraPage = true; pager.adapter?.notifyDataSetChanged() }
                pager.setCurrentItem(n, true)
            }
            handler.postDelayed(this, 900)
        }
    }

    private fun edgeHover(x: Float) {
        val d = when { x < dp(36) -> -1; x > root.width - dp(36) -> 1; else -> 0 }
        if (d != hoverDir) { handler.removeCallbacks(hoverRun); hoverDir = d; if (d != 0) handler.postDelayed(hoverRun, 700) }
    }

    private fun barIndex(x: Float, y: Float): Int =
        if (dragBar.visibility == View.VISIBLE && y <= dragBar.bottom) (x / (root.width / 3f)).toInt().coerceIn(0, 2) else -1

    private fun onDrag(ev: DragEvent): Boolean {
        when (ev.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                val it = dragItem ?: return false
                dragStart = PointF(ev.x, ev.y)
                dragBar.visibility = View.VISIBLE
                dragBar.getChildAt(1).visibility = if (it.type == "APP") View.VISIBLE else View.INVISIBLE
                dragBar.getChildAt(2).visibility = if (it.type == "APP") View.VISIBLE else View.INVISIBLE
                return true
            }
            DragEvent.ACTION_DRAG_LOCATION -> {
                edgeHover(ev.x)
                val bi = barIndex(ev.x, ev.y)
                for (i in 0 until dragBar.childCount) dragBar.getChildAt(i).alpha = if (bi == -1 || bi == i) 1f else 0.4f
                return true
            }
            DragEvent.ACTION_DROP -> { handleDrop(ev.x, ev.y); return true }
            DragEvent.ACTION_DRAG_ENDED -> {
                dragItem = null; dragBar.visibility = View.GONE; extraPage = false
                hoverDir = 0; handler.removeCallbacks(hoverRun); refreshAll(); return true
            }
        }
        return true
    }

    private fun rectIn(v: View): Rect { val r = Rect(0, 0, v.width, v.height); root.offsetDescendantRectToMyCoords(v, r); return r }

    private fun handleDrop(x: Float, y: Float) {
        val item = dragItem ?: return
        val bi = barIndex(x, y)
        if (bi != -1) {
            when (bi) { 0 -> removeItem(item); 1 -> if (item.type == "APP") appInfo(item.pkg); 2 -> if (item.type == "APP") uninstall(item.pkg) }
            return
        }
        val moved = Math.hypot((x - dragStart.x).toDouble(), (y - dragStart.y).toDouble()) > dp(20)
        if (!moved) { showItemMenu(item, x.toInt(), y.toInt()); return }

        val inDock = rectIn(dock).contains(x.toInt(), y.toInt())
        val cl = if (inDock) dock else (currentPage() ?: return)
        if (inDock && item.type == "WIDGET") { toast("Widget dock'a eklenemez"); return }
        val r = rectIn(cl)
        val (gx, gy) = cl.cellAt(x - r.left, y - r.top)
        val pg = if (inDock) -1 else pager.currentItem
        val c = if (inDock) Prefs.dockN else Prefs.cols
        val rw = if (inDock) 1 else Prefs.rows
        val cx = (gx - (item.sx - 1) / 2).coerceIn(0, maxOf(0, c - item.sx))
        val cy = if (inDock) 0 else (gy - (item.sy - 1) / 2).coerceIn(0, maxOf(0, rw - item.sy))

        val target = Prefs.items.firstOrNull { it !== item && it.page == pg && gx in it.x until it.x + it.sx && gy in it.y until it.y + it.sy }
        if (item.type == "APP" && target != null && (target.type == "FOLDER" || target.type == "APP")) {
            Prefs.items.remove(item)
            if (target.type == "FOLDER") { if (item.key() !in target.children) target.children.add(item.key()) }
            else {
                val f = Item(Prefs.nextId(), "FOLDER", pg, target.x, target.y, title = "Klasör")
                f.children.add(target.key()); f.children.add(item.key())
                Prefs.items.remove(target); Prefs.items.add(f)
            }
            Prefs.save(); return
        }
        val spot = if (!Prefs.occupied(pg, cx, cy, item.sx, item.sy, c, rw, item)) Pair(cx, cy) else Prefs.free(pg, item.sx, item.sy, c, rw, cx, cy, item)
        if (spot == null) { toast("Burada yer yok"); return }
        item.page = pg; item.x = spot.first; item.y = spot.second
        Prefs.save()
    }

    private fun removeItem(item: Item) {
        Prefs.items.remove(item)
        if (item.type == "WIDGET") try { wh.host.deleteAppWidgetId(item.widgetId) } catch (e: Exception) {}
        Prefs.save(); refreshAll()
    }

    // ---------------------------------------------------------------- menus
    private fun shortcutsFor(pkg: String): List<ShortcutInfo> = try {
        val q = LauncherApps.ShortcutQuery().setPackage(pkg).setQueryFlags(
            LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED)
        (la.getShortcuts(q, Process.myUserHandle()) ?: emptyList()).take(4)
    } catch (e: Exception) { emptyList() }

    private fun hasWidgets(pkg: String) = wh.mgr.installedProviders.any { it.provider.packageName == pkg }
    private fun appInfo(pkg: String) = startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
    private fun uninstall(pkg: String) = startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
    private fun hideApp(key: String) { val h = Prefs.hidden(); h.add(key); Prefs.setHidden(h); applyAll() }

    private fun appEntries(e: AppEntry): MutableList<Entry> {
        val l = mutableListOf<Entry>()
        shortcutsFor(e.pkg).forEach { si ->
            l.add(Entry(si.shortLabel?.toString() ?: "", try { la.getShortcutIconDrawable(si, 0) } catch (x: Exception) { null }) {
                try { la.startShortcut(si, null, null) } catch (x: Exception) {}
            })
        }
        if (hasWidgets(e.pkg)) l.add(Entry("🧩  Widget'lar") { widgetPicker(e.pkg) })
        l.add(Entry("ℹ️  Uygulama bilgisi") { appInfo(e.pkg) })
        return l
    }

    private fun showItemMenu(item: Item, x: Int, y: Int) {
        val l = mutableListOf<Entry>()
        when (item.type) {
            "APP" -> {
                Apps.find(item.key())?.let { l.addAll(appEntries(it)) }
                l.add(Entry("Ana ekrandan kaldır") { removeItem(item) })
                l.add(Entry("Gizle") { removeItem(item); hideApp(item.key()) })
                l.add(Entry("Uygulamayı sil") { uninstall(item.pkg) })
            }
            "FOLDER" -> {
                l.add(Entry("Yeniden adlandır") { renameFolder(item) })
                l.add(Entry("Klasörü dağıt") { dissolve(item) })
            }
            else -> {
                l.add(Entry("Yeniden boyutlandır") { resizeDialog(item) })
                l.add(Entry("Widget'ı kaldır") { removeItem(item) })
            }
        }
        showPopup(root, x, y, l, pal)
    }

    // ---------------------------------------------------------------- folders
    private fun fixFolder(f: Item) {
        f.children.removeAll { Apps.find(it) == null }
        if (f.children.size <= 1) {
            Prefs.items.remove(f)
            f.children.firstOrNull()?.let { k -> val e = Apps.find(k)!!; Prefs.items.add(Item(Prefs.nextId(), "APP", f.page, f.x, f.y, pkg = e.pkg, cls = e.cls)) }
        }
        Prefs.save()
    }
    private fun dissolve(f: Item) {
        Prefs.items.remove(f)
        for (k in f.children) { val e = Apps.find(k) ?: continue; val it = Item(Prefs.nextId(), "APP", f.page, f.x, f.y, pkg = e.pkg, cls = e.cls); if (Prefs.placeAnywhere(it, maxOf(0, f.page))) Prefs.items.add(it) }
        Prefs.save(); refreshAll()
    }
    private fun renameFolder(f: Item) {
        val et = EditText(this).apply { setText(f.title); setPadding(dp(24), dp(16), dp(24), dp(16)) }
        AlertDialog.Builder(this).setTitle("Klasör adı").setView(et)
            .setPositiveButton("Kaydet") { _, _ -> f.title = et.text.toString(); Prefs.save(); refreshAll() }.setNegativeButton("İptal", null).show()
    }
    private fun openFolder(f: Item) {
        val d = android.app.Dialog(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(20))
            background = GradientDrawable().apply { setColor(pal.surfaceVar); cornerRadius = dpf(32f) }
        }
        val title = EditText(this).apply { setText(f.title.ifEmpty { "Klasör" }); setTextColor(pal.onSurface); textSize = 18f; gravity = Gravity.CENTER; background = null }
        box.addView(title)
        val grid = GridLayout(this).apply { columnCount = 4 }
        for (k in f.children) {
            val e = Apps.find(k) ?: continue
            val v = cellView(Icons.get(this, e, iconSize(4), pal), e.label, true, NotifService.counts[e.pkg] ?: 0, pal.onSurface, iconSize(4))
            v.setOnClickListener { d.dismiss(); Apps.launch(this, e, v) }
            v.setOnLongClickListener {
                showPopup(root, lastX.toInt(), lastY.toInt(), listOf(
                    Entry("Ana ekrana taşı") { d.dismiss(); f.children.remove(k); val it = Item(Prefs.nextId(), "APP", maxOf(0, f.page), 0, 0, pkg = e.pkg, cls = e.cls); if (Prefs.placeAnywhere(it, maxOf(0, f.page))) Prefs.items.add(it); fixFolder(f); refreshAll() },
                    Entry("Uygulama bilgisi") { appInfo(e.pkg) }), pal); true
            }
            grid.addView(v, GridLayout.LayoutParams().apply { width = dp(76); height = WRAP })
        }
        box.addView(grid)
        d.setContentView(box)
        d.setOnDismissListener { f.title = title.text.toString(); Prefs.save(); refreshAll() }
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); d.show()
    }

    // ---------------------------------------------------------------- widgets
    private fun spanFor(info: AppWidgetProviderInfo): Pair<Int, Int> {
        val cw = maxOf(1f, pager.width.toFloat() / Prefs.cols); val ch = maxOf(1f, pager.height.toFloat() / Prefs.rows)
        var sx = Math.ceil((info.minWidth / cw).toDouble()).toInt(); var sy = Math.ceil((info.minHeight / ch).toDouble()).toInt()
        if (Build.VERSION.SDK_INT >= 31) { if (info.targetCellWidth > 0) sx = info.targetCellWidth; if (info.targetCellHeight > 0) sy = info.targetCellHeight }
        return Pair(sx.coerceIn(1, Prefs.cols), sy.coerceIn(1, Prefs.rows))
    }

    private fun widgetPicker(filter: String?) {
        val pm = packageManager
        val groups = wh.mgr.installedProviders.filter { filter == null || it.provider.packageName == filter }.groupBy { it.provider.packageName }
        val dlg = BottomSheetDialog(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)); setBackgroundColor(pal.surface) }
        col.addView(TextView(this).apply { text = "Widget'lar"; textSize = 22f; setTextColor(pal.onSurface); setPadding(dp(4), 0, 0, dp(12)) })
        for ((pkg, list) in groups.entries.sortedBy { en -> try { pm.getApplicationLabel(pm.getApplicationInfo(en.key, 0)).toString() } catch (e: Exception) { en.key } }) {
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (filter != null) View.VISIBLE else View.GONE }
            val head = TextView(this).apply {
                text = "$label  (${list.size})"; textSize = 16f; setTextColor(pal.onSurface); setPadding(dp(12), dp(14), dp(12), dp(14))
                background = GradientDrawable().apply { setColor(pal.surfaceVar); cornerRadius = dpf(20f) }
                setOnClickListener { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
            }
            col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }); col.addView(body)
            for (info in list) {
                val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(10), dp(8), dp(10)) }
                val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setImageDrawable(info.loadPreviewImage(this@MainActivity, 0) ?: info.loadIcon(this@MainActivity, 0)) }
                row.addView(img, LinearLayout.LayoutParams(dp(110), dp(80)))
                val (sx, sy) = spanFor(info)
                row.addView(TextView(this).apply { text = "${info.loadLabel(pm)}\n$sx × $sy"; setTextColor(pal.onSurface); setPadding(dp(14), 0, 0, 0) })
                row.setOnClickListener { dlg.dismiss(); addWidget(info) }
                body.addView(row)
            }
        }
        dlg.setContentView(ScrollView(this).apply { addView(col) }); dlg.show()
    }

    private fun addWidget(info: AppWidgetProviderInfo) {
        val id = wh.host.allocateAppWidgetId(); pendingWidget = id
        if (wh.mgr.bindAppWidgetIdIfAllowed(id, info.provider)) configureOrPlace(id)
        else @Suppress("DEPRECATION") startActivityForResult(Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id).putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider), REQ_BIND)
    }
    private fun configureOrPlace(id: Int) {
        val info = wh.mgr.getAppWidgetInfo(id)
        if (info?.configure != null) try { wh.host.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CFG, null) } catch (e: Exception) { placeWidget(id) }
        else placeWidget(id)
    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_BIND || req == REQ_CFG) {
            if (res == RESULT_OK && pendingWidget != -1) { if (req == REQ_BIND) configureOrPlace(pendingWidget) else placeWidget(pendingWidget) }
            else { try { wh.host.deleteAppWidgetId(pendingWidget) } catch (e: Exception) {} ; if (req == REQ_BIND) pendingWidget = -1 }
        }
    }
    private fun placeWidget(id: Int) {
        val info = wh.mgr.getAppWidgetInfo(id) ?: return
        val (sx, sy) = spanFor(info)
        val item = Item(Prefs.nextId(), "WIDGET", 0, 0, 0, sx, sy, widgetId = id)
        if (!Prefs.placeAnywhere(item, pager.currentItem)) { toast("Ana ekranda yer yok"); wh.host.deleteAppWidgetId(id); return }
        Prefs.items.add(item); Prefs.save(); pendingWidget = -1
        refreshAll(); pager.setCurrentItem(item.page, true)
    }
    private fun resizeDialog(item: Item) {
        val a = NumberPicker(this).apply { minValue = 1; maxValue = Prefs.cols; value = item.sx }
        val b = NumberPicker(this).apply { minValue = 1; maxValue = Prefs.rows; value = item.sy }
        val ll = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) }
        ll.addView(a); ll.addView(TextView(this).apply { text = "  ×  "; textSize = 22f }); ll.addView(b)
        AlertDialog.Builder(this).setTitle("Boyut (sütun × satır)").setView(ll).setPositiveButton("Uygula") { _, _ ->
            if (!Prefs.occupied(item.page, item.x, item.y, a.value, b.value, Prefs.cols, Prefs.rows, item)) { item.sx = a.value; item.sy = b.value; Prefs.save(); refreshAll() }
            else toast("Sığmıyor")
        }.setNegativeButton("İptal", null).show()
    }

    // ---------------------------------------------------------------- suggestions
    private fun updateSug() {
        sugRow.removeAllViews()
        val dockKeys = Prefs.items.filter { it.page == -1 }.map { it.key() }.toSet(); val hid = Prefs.hidden()
        val list = if (!Prefs.b("sugHome", true)) emptyList() else
            Prefs.top(20).filter { it !in hid && it !in dockKeys }.mapNotNull { Apps.find(it) }.take(Prefs.cols)
        sugRow.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        for (i in 0 until Prefs.cols) {
            val e = list.getOrNull(i)
            if (e == null) { sugRow.addView(Space(this), LinearLayout.LayoutParams(0, MATCH, 1f)); continue }
            val v = cellView(Icons.get(this, e, iconSize(Prefs.cols), pal), e.label, false, NotifService.counts[e.pkg] ?: 0, textColor, iconSize(Prefs.cols))
            v.setOnClickListener { Apps.launch(this, e, v) }
            v.setOnLongClickListener { showPopup(root, lastX.toInt(), lastY.toInt(), appEntries(e), pal); true }
            sugRow.addView(v, LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    // ---------------------------------------------------------------- drawer
    private fun hideKb() { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(dq.windowToken, 0); dq.clearFocus() }
    private fun webSearch(q: String) { if (q.isBlank()) return; try { startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra(android.app.SearchManager.QUERY, q)) } catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))) } }

    private fun openDrawer(focus: Boolean) {
        refreshDrawer(""); sheet.state = BottomSheetBehavior.STATE_EXPANDED
        if (focus) handler.postDelayed({ dq.requestFocus(); (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(dq, 0) }, 350)
    }

    private fun refreshDrawer(q: String) {
        val hid = Prefs.hidden(); val loc = Locale.getDefault()
        dAdapter.apps = Apps.list.filter { it.key !in hid && (q.isEmpty() || it.label.lowercase(loc).contains(q.lowercase(loc))) }
        dAdapter.sugg = if (q.isEmpty() && Prefs.b("sugDrawer", true)) Prefs.top(20).filter { it !in hid }.mapNotNull { Apps.find(it) }.take(Prefs.cols) else emptyList()
        dAdapter.web = if (q.isNotEmpty()) "“$q” için web'de ara" else null
        dAdapter.notifyDataSetChanged()
    }

    private fun drawerCell(e: AppEntry): View {
        val v = cellView(Icons.get(this, e, iconSize(Prefs.cols), pal), e.label, true, NotifService.counts[e.pkg] ?: 0, pal.onSurface, iconSize(Prefs.cols))
        v.setOnClickListener { Apps.launch(this, e, v); sheet.state = BottomSheetBehavior.STATE_HIDDEN }
        v.setOnLongClickListener {
            val l = appEntries(e)
            l.add(0, Entry("➕  Ana ekrana ekle") { addToHome(e) })
            l.add(Entry("Gizle") { hideApp(e.key) })
            l.add(Entry("Uygulamayı sil") { uninstall(e.pkg) })
            showPopup(root, lastX.toInt(), lastY.toInt(), l, pal); true
        }
        return v
    }

    private fun addToHome(e: AppEntry) {
        val it = Item(Prefs.nextId(), "APP", 0, 0, 0, pkg = e.pkg, cls = e.cls)
        if (Prefs.placeAnywhere(it, 0)) { Prefs.items.add(it); Prefs.save(); sheet.state = BottomSheetBehavior.STATE_HIDDEN; refreshAll(); toast("Ana ekrana eklendi") } else toast("Yer yok")
    }

    private inner class DrawerAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var apps: List<AppEntry> = emptyList()
        var sugg: List<AppEntry> = emptyList()
        var web: String? = null
        private val off get() = if (sugg.isNotEmpty()) 1 else 0
        override fun getItemCount() = apps.size + off + (if (web != null) 1 else 0)
        override fun getItemViewType(p: Int) = when { p < off -> 0; p >= off + apps.size -> 2; else -> 1 }
        override fun onCreateViewHolder(parent: ViewGroup, t: Int): RecyclerView.ViewHolder {
            val v: View = when (t) {
                0 -> LinearLayout(parent.context).apply { orientation = LinearLayout.HORIZONTAL; layoutParams = RecyclerView.LayoutParams(MATCH, WRAP) }
                2 -> TextView(parent.context).apply { layoutParams = RecyclerView.LayoutParams(MATCH, dp(56)); gravity = Gravity.CENTER_VERTICAL; textSize = 16f; setPadding(dp(20), 0, dp(20), 0) }
                else -> FrameLayout(parent.context).apply { layoutParams = RecyclerView.LayoutParams(MATCH, WRAP) }
            }
            return object : RecyclerView.ViewHolder(v) {}
        }
        override fun onBindViewHolder(h: RecyclerView.ViewHolder, p: Int) {
            when (h.itemViewType) {
                0 -> {
                    val ll = h.itemView as LinearLayout; ll.removeAllViews()
                    for (i in 0 until Prefs.cols) { val e = sugg.getOrNull(i); ll.addView(if (e != null) drawerCell(e) else Space(ll.context), LinearLayout.LayoutParams(0, WRAP, 1f)) }
                }
                2 -> (h.itemView as TextView).apply { text = web; setTextColor(pal.primary); setOnClickListener { webSearch(dq.text.toString()) } }
                else -> (h.itemView as FrameLayout).apply { removeAllViews(); addView(drawerCell(apps[p - off])) }
            }
        }
    }

    // ---------------------------------------------------------------- gestures
    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                if (Math.abs(vy) > Math.abs(vx) * 1.5f && Math.abs(dy) > dp(80)) {
                    if (dy < 0) openDrawer(false)
                    else if (Prefs.b("swipeDown", true)) expandNotifs()
                }
                return false
            }
        })
    }

    private fun expandNotifs() {
        try { Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(getSystemService("statusbar")) } catch (e: Exception) {}
    }

    private fun onWidget(x: Float, y: Float): Boolean {
        val c = currentPage() ?: return false; val r = rectIn(c)
        return (0 until c.childCount).any {
            val v = c.getChildAt(it)
            (v.tag as? Item)?.type == "WIDGET" && Rect(v.left + r.left, v.top + r.top, v.right + r.left, v.bottom + r.top).contains(x.toInt(), y.toInt())
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            lastX = ev.rawX; lastY = ev.rawY
            gestureOk = ::sheet.isInitialized && sheet.state == BottomSheetBehavior.STATE_HIDDEN && dragItem == null && !onWidget(ev.x, ev.y)
        }
        if (gestureOk) gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- package callbacks
    private val cb = object : LauncherApps.Callback() {
        override fun onPackageRemoved(p: String?, u: UserHandle?) { appsChanged(p, false) }
        override fun onPackageAdded(p: String?, u: UserHandle?) { appsChanged(p, true) }
        override fun onPackageChanged(p: String?, u: UserHandle?) { appsChanged(p, false) }
        override fun onPackagesAvailable(p: Array<out String>?, u: UserHandle?, r: Boolean) { appsChanged(null, false) }
        override fun onPackagesUnavailable(p: Array<out String>?, u: UserHandle?, r: Boolean) { appsChanged(null, false) }
    }

    private fun appsChanged(pkg: String?, added: Boolean) = runOnUiThread {
        Apps.load(this)
        Prefs.items.removeAll { it.type == "APP" && Apps.find(it.key()) == null }
        Prefs.items.filter { it.type == "FOLDER" }.toList().forEach { fixFolder(it) }
        if (added && pkg != null && Prefs.b("autoAdd", true) && Prefs.items.none { it.pkg == pkg }) {
            Apps.list.firstOrNull { it.pkg == pkg }?.let { e ->
                val it = Item(Prefs.nextId(), "APP", 0, 0, 0, pkg = e.pkg, cls = e.cls); if (Prefs.placeAnywhere(it, 0)) Prefs.items.add(it)
            }
        }
        Prefs.save(); refreshAll(); refreshDrawer(dq.text.toString())
    }
}
