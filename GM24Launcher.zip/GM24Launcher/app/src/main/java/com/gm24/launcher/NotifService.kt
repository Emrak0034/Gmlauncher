package com.gm24.launcher

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifService : NotificationListenerService() {
    companion object {
        val counts = HashMap<String, Int>()
        var onChange: (() -> Unit)? = null
    }
    override fun onListenerConnected() { refresh() }
    override fun onNotificationPosted(sbn: StatusBarNotification?) { refresh() }
    override fun onNotificationRemoved(sbn: StatusBarNotification?) { refresh() }

    private fun refresh() {
        val m = HashMap<String, Int>()
        try {
            activeNotifications?.forEach {
                if (!it.isOngoing && (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0)
                    m[it.packageName] = (m[it.packageName] ?: 0) + 1
            }
        } catch (e: Exception) {}
        counts.clear(); counts.putAll(m)
        Handler(Looper.getMainLooper()).post { onChange?.invoke() }
    }
}
