package com.gm24.launcher

import android.Manifest
import android.app.AlarmManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Geocoder
import android.location.LocationManager
import android.os.BatteryManager
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Wx(val temp: Int, val code: Int, val hi: Int, val lo: Int, val city: String)

/** Pixel "At a Glance" kartı: solda hava, sağda bugünkü etkinlikler. Veriler arka planda yüklenir. */
class GlanceView(c: Context) : LinearLayout(c) {
    private val card = LinearLayout(c)
    private val left = LinearLayout(c)
    private val right = LinearLayout(c)
    private val div = View(c)
    private val l1 = TextView(c); private val l2 = TextView(c); private val l3 = TextView(c)
    private val r1 = TextView(c); private val r2 = TextView(c); private val r3 = TextView(c); private val r4 = TextView(c); private val r5 = TextView(c)
    var onLong: (() -> Unit)? = null

    companion object {
        var wx: Wx? = null; var wxAt = 0L; var wxBusy = false
        var evs: List<String> = emptyList(); var evTotal = 0; var evAt = 0L; var evBusy = false
    }

    init {
        orientation = VERTICAL
        setPadding(c.dp(16), c.dp(14), c.dp(16), c.dp(6))
        card.orientation = HORIZONTAL; card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(c.dp(18), c.dp(16), c.dp(18), c.dp(16))
        left.orientation = VERTICAL; right.orientation = VERTICAL
        l1.textSize = 13f; l1.typeface = Typeface.DEFAULT_BOLD
        l2.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        l3.textSize = 11f
        r1.textSize = 13f; r1.typeface = Typeface.DEFAULT_BOLD
        r2.textSize = 11f; r3.textSize = 12f; r4.textSize = 12f; r5.textSize = 11f
        r3.setPadding(0, c.dp(6), 0, 0)
        listOf(l1, l2, l3).forEach { left.addView(it) }
        listOf(r1, r2, r3, r4, r5).forEach { right.addView(it) }
        card.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        card.addView(div, LinearLayout.LayoutParams(c.dp(1), c.dp(76)).apply { setMargins(c.dp(14), 0, c.dp(14), 0) })
        card.addView(right, LinearLayout.LayoutParams(0, WRAP, 1f))
        addView(card, LinearLayout.LayoutParams(MATCH, WRAP))
        setOnLongClickListener { onLong?.invoke(); true }
        setOnClickListener {
            try { context.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
    }

    fun style(col: Int) {}

    private fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    private fun put(v: TextView, t: String?) {
        if (t.isNullOrEmpty()) v.visibility = GONE else { v.text = t; v.visibility = VISIBLE }
    }

    fun refresh() { render(); load() }

    private fun render() {
        val pal = Pal.get(context)
        card.background = GradientDrawable().apply { setColor(pal.surface); setAlpha(238); cornerRadius = context.dpf(28f) }
        div.setBackgroundColor(pal.onSurface and 0x00FFFFFF or 0x33000000)
        val sec = pal.onSurface and 0x00FFFFFF or 0xAA000000.toInt()
        listOf(l1, l2, r1, r3, r4).forEach { it.setTextColor(pal.onSurface) }
        listOf(l3, r2, r5).forEach { it.setTextColor(sec) }

        val showW = Prefs.b("gl_weather", true); val showC = Prefs.b("gl_calendar", true)
        val w = wx
        if (showW && w != null) {
            l2.textSize = 34f
            put(l1, (emoji(w.code) + " " + w.city).trim()); put(l2, "${w.temp}°")
            put(l3, cond(w.code) + "\nY:${w.hi}° D:${w.lo}°")
        } else {
            l2.textSize = 24f
            put(l1, null)
            put(l2, java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEdMMM"), Locale.getDefault()).format(Date()))
            put(l3, if (showW) "Hava durumu için konum izni ver" else null)
        }

        if (showC) {
            put(r1, "Bugün")
            if (!granted(Manifest.permission.READ_CALENDAR)) { put(r2, "Takvim izni gerekli"); put(r3, null); put(r4, null) }
            else { put(r2, if (evTotal == 0) "Etkinlik yok" else "$evTotal etkinlik"); put(r3, evs.getOrNull(0)); put(r4, evs.getOrNull(1)) }
        } else { put(r1, null); put(r2, null); put(r3, null); put(r4, null) }
        val extra = mutableListOf<String>()
        if (Prefs.b("gl_alarm", true)) alarm()?.let { extra.add(it) }
        if (Prefs.b("gl_battery", true)) battery()?.let { extra.add(it) }
        put(r5, extra.joinToString("   "))
        val rightOn = showC || extra.isNotEmpty()
        right.visibility = if (rightOn) VISIBLE else GONE
        div.visibility = if (rightOn) VISIBLE else GONE
    }

    private fun load() {
        val now = System.currentTimeMillis()
        if (Prefs.b("gl_calendar", true) && granted(Manifest.permission.READ_CALENDAR) && !evBusy && now - evAt > 60_000L) {
            evBusy = true
            Thread { loadEvents(); evAt = System.currentTimeMillis(); evBusy = false; post { render() } }.start()
        }
        val iv = if (wx == null) 120_000L else 1_800_000L
        if (Prefs.b("gl_weather", true) && granted(Manifest.permission.ACCESS_COARSE_LOCATION) && !wxBusy && now - wxAt > iv) {
            wxBusy = true
            Thread { loadWeather(); wxAt = System.currentTimeMillis(); wxBusy = false; post { render() } }.start()
        }
    }

    private fun loadEvents() {
        try {
            val now = System.currentTimeMillis()
            val end = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, now); ContentUris.appendId(b, end)
            val list = mutableListOf<String>(); var total = 0
            context.contentResolver.query(b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { cur ->
                while (cur.moveToNext()) {
                    if (cur.getInt(2) == 1) continue
                    total++
                    if (list.size < 2) list.add(DateFormat.getTimeFormat(context).format(Date(cur.getLong(1))) + "  " + (cur.getString(0) ?: "Etkinlik"))
                }
            }
            evs = list; evTotal = total
        } catch (e: Exception) {}
    }

    private fun loadWeather() {
        try {
            val lm = context.getSystemService(LocationManager::class.java)
            val loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER) ?: return
            val u = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1")
            val txt = (u.openConnection() as HttpURLConnection).run { connectTimeout = 8000; readTimeout = 8000; inputStream.bufferedReader().readText() }
            val o = JSONObject(txt); val cur = o.getJSONObject("current"); val d = o.getJSONObject("daily")
            var city = ""
            try {
                if (Geocoder.isPresent()) {
                    @Suppress("DEPRECATION")
                    val a = Geocoder(context, Locale("tr", "TR")).getFromLocation(loc.latitude, loc.longitude, 1)
                    city = a?.firstOrNull()?.let { it.subAdminArea ?: it.locality ?: it.adminArea } ?: ""
                }
            } catch (e: Exception) {}
            wx = Wx(Math.round(cur.getDouble("temperature_2m")).toInt(), cur.getInt("weather_code"),
                Math.round(d.getJSONArray("temperature_2m_max").getDouble(0)).toInt(), Math.round(d.getJSONArray("temperature_2m_min").getDouble(0)).toInt(), city)
        } catch (e: Exception) {}
    }

    private fun alarm(): String? {
        val t = context.getSystemService(AlarmManager::class.java).nextAlarmClock?.triggerTime ?: return null
        if (t - System.currentTimeMillis() > 12 * 3600_000L) return null
        return "⏰ " + DateFormat.getTimeFormat(context).format(Date(t))
    }

    private fun battery(): String? {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / maxOf(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return if (chg) "🔋 %$lvl şarj oluyor" else if (lvl <= 15) "🪫 Pil %$lvl" else null
    }

    private fun emoji(code: Int) = when (code) {
        0 -> "☀️"; 1, 2 -> "🌤"; 3 -> "☁️"; 45, 48 -> "🌫"
        in 51..67, in 80..82 -> "🌧"; in 71..77, 85, 86 -> "❄️"; in 95..99 -> "⛈"; else -> "🌡"
    }

    private fun cond(code: Int) = when (code) {
        0 -> "Açık"; 1, 2 -> "Parçalı bulutlu"; 3 -> "Bulutlu"; 45, 48 -> "Sisli"
        in 51..67, in 80..82 -> "Yağmurlu"; in 71..77, 85, 86 -> "Karlı"; in 95..99 -> "Fırtınalı"; else -> ""
    }
}
