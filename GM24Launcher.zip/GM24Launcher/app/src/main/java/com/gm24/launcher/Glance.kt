package com.gm24.launcher

import android.Manifest
import android.app.AlarmManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.location.LocationManager
import android.os.BatteryManager
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date
import java.util.Locale

class GlanceView(c: Context) : LinearLayout(c) {
    private val date = TextView(c)
    private val info = TextView(c)
    var onLong: (() -> Unit)? = null

    companion object { var weather: String? = null; var lastW = 0L }

    init {
        orientation = VERTICAL
        setPadding(c.dp(28), c.dp(18), c.dp(28), c.dp(8))
        date.textSize = 32f; date.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        info.textSize = 14f
        addView(date); addView(info)
        setOnLongClickListener { onLong?.invoke(); true }
        setOnClickListener {
            try { context.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
        }
    }

    fun style(col: Int) {
        listOf(date, info).forEach { it.setTextColor(col); it.setShadowLayer(4f, 0f, 1f, 0x44000000) }
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(context, p) == PackageManager.PERMISSION_GRANTED

    fun refresh() {
        date.text = java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEdMMM"), Locale.getDefault()).format(Date())
        val parts = mutableListOf<String>()
        if (Prefs.b("gl_weather", true)) weather?.let { parts.add(it) }
        if (Prefs.b("gl_calendar", true)) nextEvent()?.let { parts.add(it) }
        if (Prefs.b("gl_alarm", true)) alarm()?.let { parts.add(it) }
        if (Prefs.b("gl_battery", true)) battery()?.let { parts.add(it) }
        info.text = parts.joinToString("   •   ")
        info.visibility = if (parts.isEmpty()) GONE else VISIBLE
        fetchWeather()
    }

    private fun alarm(): String? {
        val t = context.getSystemService(AlarmManager::class.java).nextAlarmClock?.triggerTime ?: return null
        if (t - System.currentTimeMillis() > 12 * 3600_000L) return null
        return "⏰ " + DateFormat.getTimeFormat(context).format(Date(t))
    }

    private fun battery(): String? {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / maxOf(1, i.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        return if (chg) "🔋 %$lvl şarj oluyor" else if (lvl <= 15) "🪫 Pil %$lvl" else null
    }

    private fun nextEvent(): String? {
        if (!granted(Manifest.permission.READ_CALENDAR)) return null
        return try {
            val now = System.currentTimeMillis()
            val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
            ContentUris.appendId(b, now); ContentUris.appendId(b, now + 24 * 3600_000L)
            context.contentResolver.query(b.build(),
                arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                var r: String? = null
                while (r == null && c.moveToNext()) {
                    if (c.getInt(2) == 1) continue
                    r = "📅 " + (c.getString(0) ?: "Etkinlik") + " " + DateFormat.getTimeFormat(context).format(Date(c.getLong(1)))
                }
                r
            }
        } catch (e: Exception) { null }
    }

    private fun emoji(code: Int) = when (code) {
        0 -> "☀️"; 1, 2 -> "🌤"; 3 -> "☁️"; 45, 48 -> "🌫"
        in 51..67, in 80..82 -> "🌧"; in 71..77, 85, 86 -> "❄️"; in 95..99 -> "⛈"; else -> "🌡"
    }

    private fun fetchWeather() {
        if (!Prefs.b("gl_weather", true) || !granted(Manifest.permission.ACCESS_COARSE_LOCATION)) return
        if (weather != null && System.currentTimeMillis() - lastW < 30 * 60_000L) return
        lastW = System.currentTimeMillis()
        val lm = context.getSystemService(LocationManager::class.java)
        val loc = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER) } catch (e: SecurityException) { null } ?: return
        Thread {
            try {
                val u = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code")
                val txt = (u.openConnection() as HttpURLConnection).run { connectTimeout = 8000; readTimeout = 8000; inputStream.bufferedReader().readText() }
                val cur = JSONObject(txt).getJSONObject("current")
                weather = emoji(cur.getInt("weather_code")) + " " + Math.round(cur.getDouble("temperature_2m")) + "°"
                post { refresh() }
            } catch (e: Exception) { lastW = 0L }
        }.start()
    }
}
