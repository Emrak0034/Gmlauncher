package com.gm24.launcher

import android.app.ActivityOptions
import android.content.Context
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Rect
import android.os.Process
import android.view.View
import java.text.Collator
import java.util.Locale

data class AppEntry(val pkg: String, val cls: String, val label: String, val info: LauncherActivityInfo) {
    val key get() = "$pkg/$cls"
}

object Apps {
    var list: List<AppEntry> = emptyList()

    fun load(ctx: Context) {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val col = Collator.getInstance(Locale.getDefault())
        list = la.getActivityList(null, Process.myUserHandle())
            .filter { it.componentName.packageName != ctx.packageName }
            .map { AppEntry(it.componentName.packageName, it.componentName.className, it.label.toString(), it) }
            .sortedWith { a, b -> col.compare(a.label, b.label) }
    }
    fun find(key: String) = list.firstOrNull { it.key == key }

    fun launch(ctx: Context, e: AppEntry, v: View?) {
        try {
            val la = ctx.getSystemService(LauncherApps::class.java)
            var r: Rect? = null; var opt: android.os.Bundle? = null
            if (v != null) {
                r = Rect(); v.getGlobalVisibleRect(r)
                opt = ActivityOptions.makeClipRevealAnimation(v, 0, 0, v.width, v.height).toBundle()
            }
            la.startMainActivity(e.info.componentName, Process.myUserHandle(), r, opt)
            Prefs.bump(e.key)
        } catch (ex: Exception) {}
    }
}
