package com.gm24.launcher

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import org.json.JSONArray
import org.json.JSONObject

/** type: APP | FOLDER | WIDGET ; page -1 = dock */
data class Item(
    var id: Long, var type: String, var page: Int, var x: Int, var y: Int,
    var sx: Int = 1, var sy: Int = 1,
    var pkg: String = "", var cls: String = "",
    var widgetId: Int = -1, var title: String = "",
    val children: MutableList<String> = mutableListOf()
) {
    fun key() = "$pkg/$cls"
    fun toJson(): JSONObject = JSONObject().put("id", id).put("t", type).put("p", page).put("x", x).put("y", y)
        .put("sx", sx).put("sy", sy).put("pkg", pkg).put("cls", cls).put("w", widgetId).put("title", title)
        .put("ch", JSONArray(children))

    companion object {
        fun from(o: JSONObject): Item {
            val ch = mutableListOf<String>()
            o.optJSONArray("ch")?.let { for (i in 0 until it.length()) ch.add(it.getString(i)) }
            return Item(o.getLong("id"), o.getString("t"), o.getInt("p"), o.getInt("x"), o.getInt("y"),
                o.optInt("sx", 1), o.optInt("sy", 1), o.optString("pkg"), o.optString("cls"),
                o.optInt("w", -1), o.optString("title"), ch)
        }
    }
}

object Prefs {
    lateinit var sp: SharedPreferences
    @Volatile var dirty = false
    val items = mutableListOf<Item>()

    fun init(c: Context) { sp = c.getSharedPreferences("launcher", Context.MODE_PRIVATE); load() }
    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun s(k: String, d: String) = sp.getString(k, d) ?: d
    fun any(k: String): Any? = sp.all[k]
    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) { is Boolean -> e.putBoolean(k, v); is Int -> e.putInt(k, v); is String -> e.putString(k, v); is Long -> e.putLong(k, v) }
        e.apply(); dirty = true
    }

    val cols get() = i("cols", 4)
    val rows get() = i("rows", 5)
    val dockN get() = i("dockN", 4)

    fun nightMode() = when (i("theme", 0)) { 1 -> AppCompatDelegate.MODE_NIGHT_NO; 2 -> AppCompatDelegate.MODE_NIGHT_YES; else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM }

    fun load() {
        items.clear()
        try { val a = JSONArray(sp.getString("items", "[]")); for (n in 0 until a.length()) items.add(Item.from(a.getJSONObject(n))) } catch (e: Exception) {}
    }
    fun save() { val a = JSONArray(); items.forEach { a.put(it.toJson()) }; sp.edit().putString("items", a.toString()).apply() }
    fun nextId(): Long { val n = sp.getLong("nid", 1L); sp.edit().putLong("nid", n + 1).apply(); return n }

    fun hidden(): MutableSet<String> = sp.getStringSet("hidden", emptySet())!!.toMutableSet()
    fun setHidden(s: Set<String>) { sp.edit().putStringSet("hidden", s).apply(); dirty = true }

    fun bump(key: String) {
        val o = JSONObject(sp.getString("counts", "{}")!!); o.put(key, o.optInt(key) + 1)
        sp.edit().putString("counts", o.toString()).apply()
    }
    fun top(n: Int): List<String> {
        val o = JSONObject(sp.getString("counts", "{}")!!)
        return o.keys().asSequence().sortedByDescending { o.getInt(it) }.take(n).toList()
    }

    fun occupied(pg: Int, x: Int, y: Int, sx: Int, sy: Int, c: Int, r: Int, ignore: Item?): Boolean {
        if (x < 0 || y < 0 || x + sx > c || y + sy > r) return true
        return items.any { it !== ignore && it.page == pg && x < it.x + it.sx && x + sx > it.x && y < it.y + it.sy && y + sy > it.y }
    }
    fun free(pg: Int, sx: Int, sy: Int, c: Int, r: Int, nx: Int = 0, ny: Int = 0, ignore: Item? = null): Pair<Int, Int>? {
        var best: Pair<Int, Int>? = null; var bd = Int.MAX_VALUE
        for (y in 0..(r - sy)) for (x in 0..(c - sx)) if (!occupied(pg, x, y, sx, sy, c, r, ignore)) {
            val d = (x - nx) * (x - nx) + (y - ny) * (y - ny); if (d < bd) { bd = d; best = Pair(x, y) }
        }
        return best
    }
    fun placeAnywhere(item: Item, startPage: Int = 0): Boolean {
        val last = (items.filter { it.page >= 0 }.maxOfOrNull { it.page } ?: 0) + 1
        var pg = startPage
        while (pg <= last) {
            val f = free(pg, item.sx, item.sy, cols, rows, 0, 0, item)
            if (f != null) { item.page = pg; item.x = f.first; item.y = f.second; return true }
            pg++
        }
        return false
    }
    /** Grid değişince taşan öğeleri yeniden yerleştirir. */
    fun relayout() {
        val bad = items.filter { if (it.page == -1) it.x >= dockN else it.x + it.sx > cols || it.y + it.sy > rows }
        items.removeAll(bad.toSet())
        for (b in bad) {
            b.sx = minOf(b.sx, cols); b.sy = minOf(b.sy, rows)
            if (b.page == -1) { b.sx = 1; b.sy = 1 }
            if (placeAnywhere(b, maxOf(0, b.page))) items.add(b)
        }
        save()
    }
}
