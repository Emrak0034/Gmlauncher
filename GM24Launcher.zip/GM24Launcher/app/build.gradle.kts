plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gm24.launcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gm24.launcher"
        minSdk = 31
        targetSdk = 34
        versionCode = 3
        versionName = "3.0"
    }
    signingConfigs {
        create("gm24") { storeFile = file("gm24.jks"); storePassword = "gm24pass"; keyAlias = "gm24"; keyPassword = "gm24pass" }
    }
    buildTypes {
        // Hızlı çalışsın diye "debug" de R8 ile küçültülür ve debuggable kapalıdır; imza sabit (güncelleme üstüne kurulur).
        debug {
            isDebuggable = false; isMinifyEnabled = true; isShrinkResources = true
            signingConfig = signingConfigs.getByName("gm24")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        release {
            isMinifyEnabled = true; isShrinkResources = true
            signingConfig = signingConfigs.getByName("gm24")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
